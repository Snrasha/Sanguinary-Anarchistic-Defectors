package src.data.scripts.campaign.raid;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener.FleetDespawnReason;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI.EconomyUpdateListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.MutableStat.StatMod;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.CustomRepImpact;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.fleets.RouteLocationCalculator;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.PersonBountyIntel.BountyResult;
import com.fs.starfarer.api.impl.campaign.intel.PersonBountyIntel.BountyResultType;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.PirateBaseRumorBarEvent;
import com.fs.starfarer.api.impl.campaign.intel.deciv.DecivTracker;
import com.fs.starfarer.api.impl.campaign.intel.raid.RaidIntel;
import com.fs.starfarer.api.impl.campaign.intel.raid.ReturnStage;
import com.fs.starfarer.api.impl.campaign.intel.raid.TravelStage;
import com.fs.starfarer.api.impl.campaign.intel.raid.RaidIntel.RaidDelegate;
import com.fs.starfarer.api.impl.campaign.intel.raid.RaidIntel.RaidStageStatus;
import com.fs.starfarer.api.impl.campaign.procgen.MarkovNames;
import com.fs.starfarer.api.impl.campaign.procgen.MarkovNames.MarkovNameResult;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.AddedEntity;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.EntityLocation;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator.LocationType;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import src.data.scripts.campaign.SAD_StationFleetManager;

public class SAD_BaseIntel extends BaseIntelPlugin implements EveryFrameScript, FleetEventListener,
        EconomyUpdateListener, RaidDelegate {

    public static enum SAD_PowerTier {
        TIER_1_1MODULE,
        TIER_2_1MODULE,
        TIER_3_2MODULE,
        TIER_4_3MODULE,
        TIER_5_3MODULE,
    }

    public static Logger log = Global.getLogger(SAD_BaseIntel.class);

    protected StarSystemAPI system;
    //protected MarketAPI market;
    protected SectorEntityToken entity;

    protected float elapsedDays = 0f;
    protected float duration = 45f;

    protected SAD_PowerTier tier;
    protected SAD_PowerTier matchedStationToTier = null;

    protected IntervalUtil monthlyInterval = new IntervalUtil(20f, 40f);
    protected int raidTimeoutMonths = 0;

    public SAD_BaseIntel(StarSystemAPI system, String factionId, SAD_PowerTier tier) {
        this.system = system;
        this.tier = tier;
        /*
                List<CampaignFleetAPI> stations = addBattlestations(data, 1f, 1, 1, createStringPicker("SAD_MotherShip_Standard", 10f));
                    for (CampaignFleetAPI station : stations) {
                        int maxFleets = 8 + random.nextInt(5);
                        SAD_StationFleetManager activeFleets = new SAD_StationFleetManager(
                                station, 1f, 0, maxFleets, 10f, 8, 24);
                        data.system.addScript(activeFleets);
                    }*/
        List<SectorEntityToken> stations = system.getEntitiesWithTag("sad_station");
        if (stations.isEmpty()) {
            //create a new station
        } else {
            entity = stations.get(0);
        }
        /*
		market = Global.getFactory().createMarket(Misc.genUID(), "SAD Base", 3);
		market.setSize(3);
		market.setHidden(true);
		
		market.setFactionId("sad");
		
		market.setSurveyLevel(SurveyLevel.FULL);
		
		market.setFactionId(factionId);
		market.addCondition(Conditions.POPULATION_3);
		
		market.addIndustry(Industries.POPULATION);
		market.addIndustry(Industries.SPACEPORT);
		market.addIndustry(Industries.MILITARYBASE);
		
		market.addSubmarket(Submarkets.SUBMARKET_OPEN);
		market.addSubmarket(Submarkets.SUBMARKET_BLACK);
		
		market.getTariff().modifyFlat("default_tariff", market.getFaction().getTariffFraction());
         */
        LinkedHashMap<LocationType, Float> weights = new LinkedHashMap<LocationType, Float>();
        weights.put(LocationType.IN_ASTEROID_BELT, 10f);
        weights.put(LocationType.IN_ASTEROID_FIELD, 10f);
        weights.put(LocationType.IN_RING, 10f);
        weights.put(LocationType.IN_SMALL_NEBULA, 10f);
        weights.put(LocationType.GAS_GIANT_ORBIT, 10f);
        weights.put(LocationType.PLANET_ORBIT, 10f);
        WeightedRandomPicker<EntityLocation> locs = BaseThemeGenerator.getLocations(null, system, null, 100f, weights);
        EntityLocation loc = locs.pick();

        if (loc == null) {
            endImmediately();
            return;
        }
        /*
		AddedEntity added = BaseThemeGenerator.addNonSalvageEntity(system, loc, Entities.MAKESHIFT_STATION, factionId);
		
		if (added == null || added.entity == null) {
			endImmediately();
			return;
		}
		
		entity = added.entity;
         */

        String name = generateName();
        if (name == null) {
            endImmediately();
            return;
        }

        /*market.setName(name);*/
        entity.setName(name);

        BaseThemeGenerator.convertOrbitWithSpin(entity, -5f);
        /*
		market.setPrimaryEntity(entity);
		entity.setMarket(market);
		
		entity.setSensorProfile(1f);
		entity.setDiscoverable(true);
		entity.getDetectedRangeMod().modifyFlat("gen", 5000f);
		
		market.setEconGroup(market.getId());
		market.getMemoryWithoutUpdate().set(DecivTracker.NO_DECIV_KEY, true);
		
		market.reapplyIndustries();
		
		Global.getSector().getEconomy().addMarket(market, true);
         */
        log.info(String.format("Added sad base in [%s], tier: %s", system.getName(), tier.name()));

        Global.getSector().getIntelManager().addIntel(this, true);
        timestamp = null;

        Global.getSector().getListenerManager().addListener(this);
        Global.getSector().getEconomy().addUpdateListener(this);
        updateTarget();
    }

    @Override
    public boolean isHidden() {
        if (super.isHidden()) {
            return true;
        }
        //if (true) return false;
        return timestamp == null;
    }

    public float getRaidFP() {
        float base = getBaseRaidFP();
        return base * (0.75f + (float) Math.random() * 0.5f);
    }

    public float getBaseRaidFP() {
        float base = 100f;
        switch (tier) {
            case TIER_1_1MODULE:
                base = 100f;
                break;
            case TIER_2_1MODULE:
                base = 200f;
                break;
            case TIER_3_2MODULE:
                base = 350f;
                break;
            case TIER_4_3MODULE:
                base = 600f;
                break;
            case TIER_5_3MODULE:
                base = 900f;
                break;
        }
        return base * (0.75f + (float) Math.random() * 0.5f);
    }

    @Override
    public void notifyRaidEnded(RaidIntel raid, RaidStageStatus status) {
        if (status == RaidStageStatus.SUCCESS) {
            raidTimeoutMonths = 0;
        } else {
            float base = getBaseRaidFP();
            float raidFP = raid.getAssembleStage().getOrigSpawnFP();
            raidTimeoutMonths += Math.round(raidFP / base) * 2;
        }
    }

    public void startRaid(StarSystemAPI target, float raidFP) {
        boolean hasTargets = false;
        for (MarketAPI curr : Misc.getMarketsInLocation(target)) {
            if (curr.getFaction().isHostileTo(getFactionForUIColors())) {
                hasTargets = true;
                break;
            }
        }

        if (!hasTargets) {
            return;
        }

        RaidIntel raid = new RaidIntel(target, getFactionForUIColors(), this);

        //float raidFP = 1000;
        float successMult = 0.75f;

        JumpPointAPI gather = null;
        List<JumpPointAPI> points = system.getEntities(JumpPointAPI.class);
        float min = Float.MAX_VALUE;
        for (JumpPointAPI curr : points) {
            float dist = Misc.getDistance(entity.getLocation(), curr.getLocation());
            if (dist < min) {
                min = dist;
                gather = curr;
            }
        }

        SAD_RaidAssembleStage assemble = new SAD_RaidAssembleStage(raid, gather, this);
        assemble.addSource(market);
        assemble.setSpawnFP(raidFP);
        assemble.setAbortFP(raidFP * successMult);
        raid.addStage(assemble);

        SectorEntityToken raidJump = RouteLocationCalculator.findJumpPointToUse(getFactionForUIColors(), target.getCenter());

        TravelStage travel = new TravelStage(raid, gather, raidJump, false);
        travel.setAbortFP(raidFP * successMult);
        raid.addStage(travel);

        SAD_RaidActionStage action = new SAD_RaidActionStage(raid, target);
        action.setAbortFP(raidFP * successMult);
        raid.addStage(action);

        raid.addStage(new ReturnStage(raid));

        boolean shouldNotify = raid.shouldSendUpdate();
        Global.getSector().getIntelManager().addIntel(raid, !shouldNotify);
    }

    public StarSystemAPI getSystem() {
        return system;
    }

    protected CampaignFleetAPI addedListenerTo = null;

    @Override
    protected void advanceImpl(float amount) {
        float days = Global.getSector().getClock().convertToDays(amount);
        if (getPlayerVisibleTimestamp() == null && isHidden()) {
            makeKnown();
            //sendUpdateIfPlayerHasIntel(DISCOVERED_PARAM, false);
        }

        CampaignFleetAPI fleet = Misc.getStationFleet(market);
        if (fleet != null && addedListenerTo != fleet) {
            if (addedListenerTo != null) {
                addedListenerTo.removeEventListener(this);
            }
            fleet.addEventListener(this);
            addedListenerTo = fleet;
        }

        if (target != null) {
            if (getAffectedMarkets(target).isEmpty()) {
                clearTarget();
            }
        }

        if (DebugFlags.RAID_DEBUG) {
            days *= 100f;
        }

        monthlyInterval.advance(days);
        if (monthlyInterval.intervalElapsed()) {
//			if (targetPlayerColonies) {
//				System.out.println("wefwefwe");
//			}
            monthsWithSameTarget++;
            raidTimeoutMonths--;
            if (raidTimeoutMonths < 0) {
                raidTimeoutMonths = 0;
            }

            if ((monthsWithSameTarget > 6 && (float) Math.random() < 0.2f) || target == null) {
                updateTarget();
            }
            //if (target != null && (float) Math.random() < 0.2f && raidTimeoutMonths <= 0) {
            boolean allowRandomRaids = SAD_BaseManager.getInstance().getDaysSinceStart() > Global.getSettings().getFloat("noPirateRaidDays");

            if (target != null
                    && (((float) Math.random() < 0.2f && allowRandomRaids)
                    || targetPlayerColonies) && raidTimeoutMonths <= 0) {
                startRaid(target, getRaidFP());
                raidTimeoutMonths = 2 + (int) Math.round((float) Math.random() * 3f);
            }

            checkForTierChange();
        }

    }

    protected void checkForTierChange() {
        if (entity.isInCurrentLocation()) {
            return;
        }

        float minMonths = Global.getSettings().getFloat("pirateBaseMinMonthsForNextTier");
        if (monthsAtCurrentTier > minMonths) {
            float prob = (monthsAtCurrentTier - minMonths) * 0.1f;
            if ((float) Math.random() < prob) {
                SAD_PowerTier next = getNextTier(tier);
                if (next != null) {
                    tier = next;
                    monthsAtCurrentTier = 0;
                    return;
                }
            }
        }

        monthsAtCurrentTier++;
    }

    protected SAD_PowerTier getNextTier(SAD_PowerTier tier) {
        switch (tier) {
            case TIER_1_1MODULE:
                return SAD_PowerTier.TIER_2_1MODULE;
            case TIER_2_1MODULE:
                return SAD_PowerTier.TIER_3_2MODULE;
            case TIER_3_2MODULE:
                return SAD_PowerTier.TIER_4_3MODULE;
            case TIER_4_3MODULE:
                return SAD_PowerTier.TIER_5_3MODULE;
            case TIER_5_3MODULE:
                return null;
        }
        return null;
    }

    protected SAD_PowerTier getPrevTier(SAD_PowerTier tier) {
        switch (tier) {
            case TIER_1_1MODULE:
                return null;
            case TIER_2_1MODULE:
                return SAD_PowerTier.TIER_1_1MODULE;
            case TIER_3_2MODULE:
                return SAD_PowerTier.TIER_2_1MODULE;
            case TIER_4_3MODULE:
                return SAD_PowerTier.TIER_3_2MODULE;
            case TIER_5_3MODULE:
                return SAD_PowerTier.TIER_4_3MODULE;
        }
        return null;
    }

    public void makeKnown() {
        makeKnown(null);
    }

    public void makeKnown(TextPanelAPI text) {
        if (getPlayerVisibleTimestamp() == null) {
            Global.getSector().getIntelManager().removeIntel(this);
            Global.getSector().getIntelManager().addIntel(this, text == null, text);
        }
    }

    @Override
    public float getTimeRemainingFraction() {
        float f = 1f - elapsedDays / duration;
        return f;
    }

    @Override
    protected void notifyEnding() {
        super.notifyEnding();
        log.info(String.format("Removing sad base at [%s]", system.getName()));
        Global.getSector().getListenerManager().removeListener(this);
        clearTarget();

        //Global.getSector().getEconomy().removeMarket(market);
        Global.getSector().getEconomy().removeUpdateListener(this);
        //Misc.removeRadioChatter(market);
        //market.advance(0f);
    }

    @Override
    protected void notifyEnded() {
        super.notifyEnded();
    }

    protected BountyResult result = null;

    @Override
    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
        if (isEnding()) {
            return;
        }

        //CampaignFleetAPI station = Misc.getStationFleet(market); // null here since it's the skeleton station at this point
        if (addedListenerTo != null && fleet == addedListenerTo) {
            Misc.fadeAndExpire(entity);
            endAfterDelay();

            boolean sendUpdate = DebugFlags.SEND_UPDATES_WHEN_NO_COMM
                    || result.type != BountyResultType.END_OTHER
                    || Global.getSector().getIntelManager().isPlayerInRangeOfCommRelay();
            sendUpdate = true;
            if (sendUpdate) {
                sendUpdateIfPlayerHasIntel(result, false);
            }

            SAD_BaseManager.getInstance().incrDestroyed();
        }
    }

    @Override
    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {

    }

    @Override
    public boolean runWhilePaused() {
        return false;
    }

    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
        Color c = getTitleColor(mode);
        info.addPara(getName(), c, 0f);
    }

    @Override
    public String getSortString() {
        String base = Misc.ucFirst(getFactionForUIColors().getPersonNamePrefix());
        return base + " Base";
    }

    public String getName() {
        String base = Misc.ucFirst(getFactionForUIColors().getPersonNamePrefix());

        String name = entity.getName();
        if (isEnding()) {
            //return "Base Abandoned - " + name;
            return base + " Base - Abandoned";
        }
        /*if (getListInfoParam() == DISCOVERED_PARAM) {
			return base + " Base - Discovered";
		}
		if (entity.isDiscoverable()) {
			return base + " Base - Exact Location Unknown";
		}*/
        return base + " Base - " + name;
    }

    @Override
    public FactionAPI getFactionForUIColors() {
        return entity.getFaction();
    }

    @Override
    public String getSmallDescriptionTitle() {
        return getName();
    }

    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {

        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        Color tc = Misc.getTextColor();
        float pad = 3f;
        float opad = 10f;

        //info.addPara(getName(), c, 0f);
        //info.addSectionHeading(getName(), Alignment.MID, 0f);
        FactionAPI faction = entity.getFaction();

        info.addImage(faction.getLogo(), width, 128, opad);

        String has = faction.getDisplayNameHasOrHave();

        info.addPara(Misc.ucFirst(faction.getDisplayNameWithArticle()) + " " + has
                + " established a base in the "
                + entity.getContainingLocation().getNameWithLowercaseType() + ". "
                + "The base serves as a staging ground for raids against nearby colonies.",
                opad, faction.getBaseUIColor(), faction.getDisplayNameWithArticleWithoutArticle());

        switch (tier) {
            case TIER_1_1MODULE:
                info.addPara("DANGER: Threat raid level: 1 "
                        + ", Threat station level: 5", opad);
                break;
            case TIER_2_1MODULE:
                info.addPara("DANGER: Threat raid level: 2 "
                        + ", Threat station level: 5", opad);
                break;
            case TIER_3_2MODULE:
                info.addPara("DANGER: Threat raid level: 3 "
                        + ", Threat station level: 5", opad);
                break;
            case TIER_4_3MODULE:
                info.addPara("DANGER: Threat raid level: 4 "
                        + ", Threat station level: 5", opad);
                break;
            case TIER_5_3MODULE:
                info.addPara("DANGER: Threat raid level: 5 "
                        + ", Threat station level: 5", opad);
                break;
        }

        info.addSectionHeading("Recent events",
                faction.getBaseUIColor(), faction.getDarkUIColor(), Alignment.MID, opad);

        if (target != null && !getAffectedMarkets(target).isEmpty() && !isEnding()) {
            info.addPara("Crazy people operating from this base have been targeting the "
                    + target.getNameWithLowercaseType() + ".", opad);
        }

        if (result != null) {
            if (result.type == BountyResultType.END_PLAYER_NO_REWARD) {
                info.addPara("You have destroyed this base.", opad);
            } else if (result.type == BountyResultType.END_OTHER) {
                info.addPara("It is rumored that this base is no longer operational.", opad);
            }
        }

    }

    public String getIcon() {
        return Global.getSettings().getSpriteName("intel", "pirate_base");
        //return market.getFaction().getCrest();
    }

    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        tags.add(Tags.INTEL_EXPLORATION);

        if (target != null && !Misc.getMarketsInLocation(target, Factions.PLAYER).isEmpty()) {
            tags.add(Tags.INTEL_COLONIES);
        }

        tags.add("sad");
        return tags;
    }

    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        //return system.getCenter();

        return entity;
    }

    protected String generateName() {
        MarkovNames.loadIfNeeded();

        MarkovNameResult gen = null;
        for (int i = 0; i < 10; i++) {
            gen = MarkovNames.generate(null);
            if (gen != null) {
                String test = gen.name;
                if (test.toLowerCase().startsWith("the ")) {
                    continue;
                }
                String p = pickPostfix();
                if (p != null && !p.isEmpty()) {
                    test += " " + p;
                }
                if (test.length() > 22) {
                    continue;
                }

                return test;
            }
        }
        return null;
    }

    protected String pickPostfix() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("Asylum");
        post.add("Astrome");
        post.add("Barrage");
        post.add("Briganderie");
        post.add("Camp");
        post.add("Cover");
        post.add("Citadel");
        post.add("Den");
        post.add("Donjon");
        post.add("Depot");
        post.add("Fort");
        post.add("Freehold");
        post.add("Freeport");
        post.add("Freehaven");
        post.add("Free Orbit");
        post.add("Galastat");
        post.add("Garrison");
        post.add("Harbor");
        post.add("Haven");
        post.add("Headquarters");
        post.add("Hideout");
        post.add("Hideaway");
        post.add("Hold");
        post.add("Lair");
        post.add("Locus");
        post.add("Main");
        post.add("Mine Depot");
        post.add("Nexus");
        post.add("Orbit");
        post.add("Port");
        post.add("Post");
        post.add("Presidio");
        post.add("Prison");
        post.add("Platform");
        post.add("Corsairie");
        post.add("Refuge");
        post.add("Retreat");
        post.add("Refinery");
        post.add("Shadow");
        post.add("Safehold");
        post.add("Starhold");
        post.add("Starport");
        post.add("Stardock");
        post.add("Sanctuary");
        post.add("Station");
        post.add("Spacedock");
        post.add("Tertiary");
        post.add("Terminus");
        post.add("Terminal");
        post.add("Tortuga");
        post.add("Ward");
        post.add("Warsat");
        return post.pick();
    }

    public void economyUpdated() {

        float fleetSizeBonus = 1f;
        float qualityBonus = 0f;
        int light = 0;
        int medium = 0;
        int heavy = 0;

        switch (tier) {
            case TIER_1_1MODULE:
                qualityBonus = 0f;
                fleetSizeBonus = 0.2f;
                break;
            case TIER_2_1MODULE:
                qualityBonus = 0.2f;
                fleetSizeBonus = 0.3f;
                light = 2;
                break;
            case TIER_3_2MODULE:
                qualityBonus = 0.3f;
                fleetSizeBonus = 0.4f;
                light = 2;
                medium = 1;
                break;
            case TIER_4_3MODULE:
                qualityBonus = 0.4f;
                fleetSizeBonus = 0.5f;
                light = 2;
                medium = 2;
                break;
            case TIER_5_3MODULE:
                qualityBonus = 0.5f;
                fleetSizeBonus = 0.75f;
                light = 2;
                medium = 2;
                heavy = 2;
                break;
        }
/*
        entity.getStats().getDynamic().getMod(Stats.FLEET_QUALITY_MOD).
                modifyFlatAlways(market.getId(), qualityBonus,
                        "Development level");

        market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyFlatAlways(market.getId(),
                fleetSizeBonus,
                "Development level");

        String modId = market.getId();
        market.getStats().getDynamic().getMod(Stats.PATROL_NUM_LIGHT_MOD).modifyFlat(modId, light);
        market.getStats().getDynamic().getMod(Stats.PATROL_NUM_MEDIUM_MOD).modifyFlat(modId, medium);
        market.getStats().getDynamic().getMod(Stats.PATROL_NUM_HEAVY_MOD).modifyFlat(modId, heavy);*/
    }

    public boolean isEconomyListenerExpired() {
        return isEnded();
    }

    /*public MarketAPI getMarket() {
        return market;
    }
*/

    protected int monthsWithSameTarget = 0;
    protected int monthsAtCurrentTier = 0;
    protected StarSystemAPI target = null;

    public void updateTarget() {
        StarSystemAPI newTarget = pickTarget();
        if (newTarget == target) {
            return;
        }

        clearTarget();

        target = newTarget;
        monthsWithSameTarget = 0;

    }

    public StarSystemAPI getTarget() {
        return target;
    }

    protected void clearTarget() {
        if (target != null) {
            target = null;
            monthsWithSameTarget = 0;
        }
    }

    public List<MarketAPI> getAffectedMarkets(StarSystemAPI system) {
        List<MarketAPI> result = new ArrayList<MarketAPI>();
        for (MarketAPI curr : Global.getSector().getEconomy().getMarkets(system)) {
            if (!affectsMarket(curr)) {
                continue;
            }
            result.add(curr);
        }
        return result;
    }

    public boolean affectsMarket(MarketAPI market) {
        if (market.isHidden()) {
            return false;
        }
        if (market.getFaction() == entity.getFaction()) {
            return false;
        }
        return true;
    }

    public void setTargetPlayerColonies(boolean targetPlayerColonies) {
        this.targetPlayerColonies = targetPlayerColonies;
    }

    public boolean isTargetPlayerColonies() {
        return targetPlayerColonies;
    }

    public StarSystemAPI getForceTarget() {
        return forceTarget;
    }

    public void setForceTarget(StarSystemAPI forceTarget) {
        this.forceTarget = forceTarget;
    }
    protected boolean targetPlayerColonies = false;
    protected StarSystemAPI forceTarget = null;

    protected StarSystemAPI pickTarget() {

        WeightedRandomPicker<StarSystemAPI> picker = new WeightedRandomPicker<StarSystemAPI>();
        boolean forceTargetIsValid = false;
        for (StarSystemAPI system : Global.getSector().getEconomy().getStarSystemsWithMarkets()) {
            float score = 0f;
            for (MarketAPI curr : Global.getSector().getEconomy().getMarkets(system)) {
                if (!affectsMarket(curr)) {
                    continue;
                }
                if (targetPlayerColonies && !curr.getFaction().isPlayerFaction()) {
                    continue;
                }

                if (system == forceTarget) {
                    forceTargetIsValid = true;
                }
                if (curr.hasCondition("sad_raid")) {
                    continue;
                }
            
                float w = curr.getSize();

                float dist = Misc.getDistance(curr.getPrimaryEntity(), market.getPrimaryEntity());
                float mult = 1f - Math.max(0f, dist - 20000f) / 20000f;
                if (mult < 0.1f) {
                    mult = 0.1f;
                }
                if (mult > 1) {
                    mult = 1;
                }

                score += w * mult;

            }
            picker.add(system, score);
        }

        if (forceTargetIsValid) {
            return forceTarget;
        }

        return picker.pick();
    }

    public List<ArrowData> getArrowData(SectorMapAPI map) {
        if (target == null || target == entity.getContainingLocation()) {
            return null;
        }

        List<ArrowData> result = new ArrayList<ArrowData>();

        SectorEntityToken entityFrom = entity;
        if (map != null) {
            SectorEntityToken iconEntity = map.getIntelIconEntity(this);
            if (iconEntity != null) {
                entityFrom = iconEntity;
            }
        }

        ArrowData arrow = new ArrowData(entityFrom, target.getCenter());
        arrow.color = getFactionForUIColors().getBaseUIColor();
        result.add(arrow);

        return result;
    }

    public float getAccessibilityPenalty() {
        switch (tier) {
            case TIER_1_1MODULE:
                return 0.1f;
            case TIER_2_1MODULE:
                return 0.2f;
            case TIER_3_2MODULE:
                return 0.3f;
            case TIER_4_3MODULE:
                return 0.4f;
            case TIER_5_3MODULE:
                return 0.5f;
        }
        return 0f;
    }

    public float getStabilityPenalty() {
        switch (tier) {
            case TIER_1_1MODULE:
                return 1f;
            case TIER_2_1MODULE:
                return 1f;
            case TIER_3_2MODULE:
                return 2f;
            case TIER_4_3MODULE:
                return 2f;
            case TIER_5_3MODULE:
                return 3f;
        }
        return 0f;
    }

    public PirateBaseTier getTier() {
        return tier;
    }

    public SectorEntityToken getEntity() {
        return entity;
    }

}
