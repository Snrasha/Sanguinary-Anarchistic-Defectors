package src.data.scripts.campaign.raid;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.raid.AssembleStage;
import com.fs.starfarer.api.impl.campaign.intel.raid.RaidIntel;

public class SAD_RaidAssembleStage extends AssembleStage {

	protected BaseIntelPlugin base;

	public SAD_RaidAssembleStage(RaidIntel raid, SectorEntityToken gatheringPoint, BaseIntelPlugin base) {
		super(raid, gatheringPoint);
		this.base = base;
	}

	@Override
	public boolean isSourceKnown() {
		return base.isPlayerVisible();
	}

	
}
