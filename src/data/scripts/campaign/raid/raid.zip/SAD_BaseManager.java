package src.data.scripts.campaign.raid;

import java.util.Random;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseEventManager;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import src.data.scripts.campaign.raid.SAD_BaseIntel.SAD_PowerTier;
import src.data.utils.SAD_Tags;

public class SAD_BaseManager extends BaseEventManager {

	public static final String KEY = "$core_sadBaseManager";
	
	public static final float CHECK_DAYS = 10f;
	public static final float CHECK_PROB = 0.5f;
	
	
	public static SAD_BaseManager getInstance() {
		Object test = Global.getSector().getMemoryWithoutUpdate().get(KEY);
		return (SAD_BaseManager) test; 
	}
	
	protected long start = 0;
	protected float extraDays = 0;
	
	protected int numDestroyed = 0;
	
	public SAD_BaseManager() {
		super();
		Global.getSector().getMemoryWithoutUpdate().set(KEY, this);
		start = Global.getSector().getClock().getTimestamp();
	}
	
	@Override
	protected int getMinConcurrent() {
            return 0;
		//return Global.getSettings().getInt("minPirateBases");
	}
	@Override
	protected int getMaxConcurrent() {
            return 1;
		//return Global.getSettings().getInt("maxPirateBases");
	}
	
	@Override
	protected float getBaseInterval() {
		return CHECK_DAYS;
	}
	
	
	@Override
	public void advance(float amount) {
		super.advance(amount);
	}





	protected Random random = new Random();
	@Override
	protected EveryFrameScript createEvent() {
		if (random.nextFloat() < CHECK_PROB) return null;
		
		StarSystemAPI system = pickSystemForPirateBase();
		if (system == null) return null;
		
		SAD_PowerTier tier = pickTier();
		
		//tier = PirateBaseTier.TIER_5_3MODULE;
		
		SAD_BaseIntel intel = new SAD_BaseIntel(system, "sad", tier);
		if (intel.isDone()) intel = null;

		return intel;
	}
	
	
	public float getDaysSinceStart() {
		float days = Global.getSector().getClock().getElapsedDaysSince(start) + extraDays;
		if (Misc.isFastStartExplorer()) {
			days += 180f - 30f;
		} else if (Misc.isFastStart()) {
			days += 180f + 60f;
		}
		return days;
	}
	
	public float getExtraDays() {
		return extraDays;
	}

	public void setExtraDays(float extraDays) {
		this.extraDays = extraDays;
	}

	protected SAD_PowerTier pickTier() {
		float days = getDaysSinceStart();
		
		days += numDestroyed * 200;
		
		WeightedRandomPicker<SAD_PowerTier> picker = new WeightedRandomPicker<SAD_PowerTier>();
		
		if (days < 360) {
			picker.add(SAD_PowerTier.TIER_1_1MODULE, 10f);
			picker.add(SAD_PowerTier.TIER_2_1MODULE, 10f);
		} else if (days < 720f) {
			picker.add(SAD_PowerTier.TIER_2_1MODULE, 10f);
			picker.add(SAD_PowerTier.TIER_3_2MODULE, 10f);
		} else if (days < 1080f) {
			picker.add(SAD_PowerTier.TIER_3_2MODULE, 10f);
			picker.add(SAD_PowerTier.TIER_4_3MODULE, 10f);
		} else {
			picker.add(SAD_PowerTier.TIER_3_2MODULE, 10f);
			picker.add(SAD_PowerTier.TIER_4_3MODULE, 10f);
			picker.add(SAD_PowerTier.TIER_5_3MODULE, 10f);
		}
		

		return picker.pick();
	}
	
	
	protected StarSystemAPI pickSystemForPirateBase() {
		WeightedRandomPicker<StarSystemAPI> far = new WeightedRandomPicker<StarSystemAPI>(random);
		WeightedRandomPicker<StarSystemAPI> picker = new WeightedRandomPicker<StarSystemAPI>(random);
		
		for (StarSystemAPI system : Global.getSector().getStarSystems()) {
			float days = Global.getSector().getClock().getElapsedDaysSince(system.getLastPlayerVisitTimestamp());
			if (days < 45f) continue;
			
			float weight = 0f;
			if (!system.hasTag(SAD_Tags.THEME_SAD))continue;
			float dist = system.getLocation().length();
			
			
			
			float distMult = 1f;
			
			if (dist > 36000f) {
				far.add(system, weight  * distMult);
			} else {
				picker.add(system, weight  * distMult);
			}
		}
		
		if (picker.isEmpty()) {
			picker.addAll(far);
		}
		
		return picker.pick();
	}

	public int getNumDestroyed() {
		return numDestroyed;
	}

	public void setNumDestroyed(int numDestroyed) {
		this.numDestroyed = numDestroyed;
	}
	
	public void incrDestroyed() {
		numDestroyed++;
	}
	
}















